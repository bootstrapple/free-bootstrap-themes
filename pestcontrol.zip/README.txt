PestControl by bootstrapple.com
Email: bootstrapple@gmail.com (Andy Suwandy)

PestControl Template is Free for personal and commercial use under MIT License
For more information about the license please visit the following link.
https://opensource.org/licenses/MIT

Images provided in this example are sourced from pixabay.com
The licenses for those images are creative common license and can be used for commercial purpose.
For more details, please visit their website.

Credits:
- JQuery.com (JQuery Library)
- http://www.icon-king.com/ (bug logo, sourced from https://www.iconfinder.com/iconsets/nuvola2)
- Sample Images from Pixabay.com