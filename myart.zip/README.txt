MyArt by TEMPLATESIFY.COM
Email: templatesify@gmail.com (Andy Suwandy)

MyArt template is Free for personal and commercial use under the CC BY License.

Images provided in this example are sourced from fotoscopy.com
The licenses for those images are creative common license and can be used for commercial purpose.
For more details, please visit their website.

Credits:
- JQuery.com (JQuery Library)
- Fotoscopy.com (sample images)
- Responsive script (bytutorial.com)