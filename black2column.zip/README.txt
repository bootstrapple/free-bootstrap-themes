Black2Column by bootstrapple.com
Email: bootstrapple@gmail.com (Andy Suwandy)

Black2Column Template is Free for personal and commercial use under MIT License
For more information about the license please visit the following link.
https://opensource.org/licenses/MIT

Images provided in this example are sourced from pixabay.com
The licenses for those images are creative common license and can be used for commercial purpose.
For more details, please visit their website.

Image gallery plugin used in Services page is Magnific Popup.

Credits:
- JQuery.com (JQuery Library)
- magnific-popup (http://dimsemenov.com/plugins/magnific-popup/)
- Sample Images from Pixabay.com
